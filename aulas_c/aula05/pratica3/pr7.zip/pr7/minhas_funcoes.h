#ifndef MYLIB
#define MYLIB

void soma1(int* ptr);

void troca(float* end_valor1, float* end_valor2);

int ddd(long long number);

#endif